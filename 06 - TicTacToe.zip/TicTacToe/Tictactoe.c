/*
    TicTacTos Program in C++ using 2D array
*/
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    cout << "*************** TIC TAC TOE *****************\n";
    // Use a 2D Array for display of the gameboard
    char gameboard[3][3] = { ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' };
    int result = 0;
    // Declaring Players and giving them symbols
    const char  PLAYER_X = 'X', PLAYER_O ='O';
    cout << "\tPlayer 1 has the symbol of  X" << endl;
    cout << "\tPlayer 2 has the symbol of  O" << endl;
    // For fetching 9 inputs
    for (int i = 1; i <= 9; i++)
    {
        system("cls");   // Clean the screen after every input
        //Displays the requestion message
        cout << "Player-X = " <<  PLAYER_X << "\nPlayer-O = " << PLAYER_O << "\n\tEnter x a Space and y coordinates for choosing the cell:\n";
        // This displays initial GameBoard
        cout << endl;
        cout << "     0   1   2" << endl;
        cout << "   +---+---+---+" << endl;
        cout << " 0" << " | " << gameboard[0][0] << " | " << gameboard[0][1] << " | " << gameboard[0][2] << " | " << endl;
        cout << "   +---+---+---+" << endl;
        cout << " 1" << " | " << gameboard[1][0] << " | " << gameboard[1][1] << " | " << gameboard[1][2] << " | " << endl;
        cout << "   +---+---+---+" << endl;
        cout << " 2" << " | " << gameboard[2][0] << " | " << gameboard[2][1] << " | " << gameboard[2][2] << " | " << endl;
        cout << "   +---+---+---+" << endl;
        // Inputing the Coordinates x and y
    static int turn = 1;
    static char comp[3][3];
    int x, y;
    //For Player-1
    if (turn % 2 == 1)
    {
        do
        {
            cout << "Player-X turn:";
            cout << "\tRow="; cin >> x; cout << "\t\tCol="; cin >> y;
            if (x < 0 || y < 0 || x > 3 || y > 3 || comp[x][y]=='.')
            cout << "Not a valid choice! Try again.\n";
        } while (x < 0 || y < 0 || x > 3 || y > 3 || comp[x][y] == '.');
        comp[x][y] = '.';
        gameboard[x][y] =  PLAYER_X;
    }
    //For Player-2
    else
    {
        do
        {
            cout << "Player-O turn:";
            cout << "\tRow="; cin >> x; cout << "\t\tCol="; cin >> y;
            if (x < 0 || y < 0 || x > 3 || y > 3 || comp[x][y] == '.')
            cout << "Not a valid choice! Try again.\n";
        } while (x < 0 || y < 0 || x > 3 || y > 3 || comp[x][y] == '.');
        comp[x][y] = '.';
        gameboard[x][y] = PLAYER_O;
    }
    turn++;
        // Check results
        if (i >= 5)     //for checking Game Result after 4 - first turns
            //For checking that either player-1 has won or not
    if (
        gameboard[0][0] ==  PLAYER_X && gameboard[0][0] == gameboard[0][1] && gameboard[0][1] == gameboard[0][2] ||
        gameboard[1][0] ==  PLAYER_X && gameboard[1][0] == gameboard[1][1] && gameboard[1][1] == gameboard[1][2] ||
        gameboard[2][0] ==  PLAYER_X && gameboard[2][0] == gameboard[2][1] && gameboard[2][1] == gameboard[2][2] ||
        gameboard[0][0] ==  PLAYER_X && gameboard[0][0] == gameboard[1][0] && gameboard[1][0] == gameboard[2][0] ||
        gameboard[0][1] ==  PLAYER_X && gameboard[0][1] == gameboard[1][1] && gameboard[1][1] == gameboard[2][1] ||
        gameboard[0][2] ==  PLAYER_X && gameboard[0][2] == gameboard[1][2] && gameboard[1][2] == gameboard[2][2] ||
        gameboard[0][0] ==  PLAYER_X && gameboard[0][0] == gameboard[1][1] && gameboard[1][1] == gameboard[2][2] ||
        gameboard[0][2] ==  PLAYER_X && gameboard[0][2] == gameboard[1][1] && gameboard[1][1] == gameboard[2][0]
        )
        result = 1;            //returns '1' if Player-1 Won
    //For checking that either player-2 has won or not if above conditions are false
    else if (
        gameboard[0][0] == PLAYER_O && gameboard[0][0] == gameboard[0][1] && gameboard[0][1] == gameboard[0][2] ||
        gameboard[1][0] == PLAYER_O && gameboard[1][0] == gameboard[1][1] && gameboard[1][1] == gameboard[1][2] ||
        gameboard[2][0] == PLAYER_O && gameboard[2][0] == gameboard[2][1] && gameboard[2][1] == gameboard[2][2] ||
        gameboard[0][0] == PLAYER_O && gameboard[0][0] == gameboard[1][0] && gameboard[1][0] == gameboard[2][0] ||
        gameboard[0][1] == PLAYER_O && gameboard[0][1] == gameboard[1][1] && gameboard[1][1] == gameboard[2][1] ||
        gameboard[0][2] == PLAYER_O && gameboard[0][2] == gameboard[1][2] && gameboard[1][2] == gameboard[2][2] ||
        gameboard[0][0] == PLAYER_O && gameboard[0][0] == gameboard[1][1] && gameboard[1][1] == gameboard[2][2] ||
        gameboard[0][2] == PLAYER_O && gameboard[0][2] == gameboard[1][1] && gameboard[1][1] == gameboard[2][0]
        )
        result = -1;            //returns '-1' if Player-2 Won
    else
        result = 0;            //returns '0' if GAME DRAW
        //For checking that either player-1 has won or not
        if (result == 1 || result == -1)
            break;
    }
    //for separating RESULT
    for (int i = 0; i < 80; i++)
        cout << "=";
    //Displays result
    cout << endl << setw(46) << "GAME RESULT\n";
    if (result == 1)
        cout << "\n" << setw(50) << "****Player-X WON****\n";
    else if (result == -1)
        cout << "\n" << setw(50) << "****Player-O WON****\n";
    else
        cout << "\n" << setw(50) << "********DRAW********\n";
    //Displays Final Game Board
    cout << endl;
        cout << "     0   1   2" << endl;
        cout << "   +---+---+---+" << endl;
        cout << " 0" << " | " << gameboard[0][0] << " | " << gameboard[0][1] << " | " << gameboard[0][2] << " | " << endl;
        cout << "   +---+---+---+" << endl;
        cout << " 1" << " | " << gameboard[1][0] << " | " << gameboard[1][1] << " | " << gameboard[1][2] << " | " << endl;
        cout << "   +---+---+---+" << endl;
        cout << " 2" << " | " << gameboard[2][0] << " | " << gameboard[2][1] << " | " << gameboard[2][2] << " | " << endl;
        cout << "   +---+---+---+" << endl;
    //For formatting output
    for (int i = 0; i < 80; i++)
        cout << "~";
    cout << endl;
    return 0;
}

